from airbot_proto import (  # pylint: disable=no-name-in-module
    types_pb2,
    utils_pb2,
    utils_pb2_grpc,
)
from airbot_proto.motion import (  # pylint: disable=no-name-in-module
    arm_pb2,
    arm_pb2_grpc,
)
